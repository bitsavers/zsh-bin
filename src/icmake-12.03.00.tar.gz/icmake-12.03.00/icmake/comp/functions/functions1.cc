//#define XERR
#include "functions.ih"

Functions::Functions()
:
    d_main(0, e_bool)
{}
