//#define XERR
#include "functions.ih"

string const Functions::s_main{ "main" };
