//#define XERR
#include "main.ih"

int main(int argc, char **argv)
try
{
    if (argc == 1)
    {
        cout << "missing filename to compile\n";
        return 1;
    }

    CompileFork cpf{ argv[1] };
    cpf.fork();
}
catch(int x)
{
    return x;
}
catch (exception const &exc)
{
    cerr << exc.what() << '\n';
}
catch (...)
{
    cerr << "unexpected exception\n";
    return 1;
}
