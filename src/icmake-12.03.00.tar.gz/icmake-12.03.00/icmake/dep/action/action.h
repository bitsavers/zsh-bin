#ifndef INCLUDED_ACTION_
#define INCLUDED_ACTION_

enum Action
{
    DRY,
    GO,
    NO_GCH,
    GCH,
    SPCH,
    UNSPECIFIED,
};
        
#endif
