//#define XERR
#include "options.ih"

void Options::spch()
{
    d_spch = SPCH;
}
