//#define XERR
#include "options.ih"

void Options::precomp()
{
    d_gch = GCH;
}
