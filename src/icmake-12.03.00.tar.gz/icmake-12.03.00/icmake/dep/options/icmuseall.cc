//#define XERR
#include "options.ih"

void Options::icmUseAll()
{
    d_useAll = s_icmconf[2];
}
