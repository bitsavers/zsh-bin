module Square;

double Square::amount() const
{
    return d_amount;
}
