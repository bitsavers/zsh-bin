module Square;

double square(double value)
{
    return g_squared = value * value;
}
