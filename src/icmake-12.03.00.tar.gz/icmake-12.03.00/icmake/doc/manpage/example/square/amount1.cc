module Square;

void Square::amount(double value)
{
    d_amount = value;
}
