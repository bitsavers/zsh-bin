module Square;

Square::Square(double amount)
:
    d_amount(amount)
{}
