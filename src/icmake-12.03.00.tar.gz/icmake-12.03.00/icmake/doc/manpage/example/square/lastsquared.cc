module Square;

double Square::lastSquared() const
{
    return g_squared;
}
