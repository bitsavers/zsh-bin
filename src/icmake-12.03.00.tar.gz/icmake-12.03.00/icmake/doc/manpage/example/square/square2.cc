module Square;

double Square::square() const
{
    return ::square(d_amount);
}
