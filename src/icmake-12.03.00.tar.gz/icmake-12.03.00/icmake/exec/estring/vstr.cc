//#define XERR
#include "estring.ih"

string const &EString::vStr() const
{
    return d_str;
}
