//#define XERR
#include "estring.ih"

bool EString::vIsString() const
{
    return true;
}
