//#define XERR
#include "estring.ih"

string EString::vto_string() const
{
    return d_str;
}
