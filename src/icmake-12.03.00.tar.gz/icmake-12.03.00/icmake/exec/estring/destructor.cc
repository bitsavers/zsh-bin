//#define XERR
#include "estring.ih"

EString::~EString()
{}
