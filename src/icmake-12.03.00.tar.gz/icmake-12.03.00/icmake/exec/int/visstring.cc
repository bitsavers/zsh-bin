//#define XERR
#include "int.ih"

bool Int::vIsString() const
{
    return false;
}
