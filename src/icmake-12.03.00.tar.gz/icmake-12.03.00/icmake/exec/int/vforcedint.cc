//#define XERR
#include "int.ih"

int Int::vForcedInt() const
{
    return d_value;
}
