//#define XERR
#include "int.ih"

int Int::vValue() const
{
    return d_value;
}
