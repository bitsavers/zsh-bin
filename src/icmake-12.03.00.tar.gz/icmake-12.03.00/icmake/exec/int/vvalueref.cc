//#define XERR
#include "int.ih"

int &Int::vValueRef()
{
    return d_value;
}
