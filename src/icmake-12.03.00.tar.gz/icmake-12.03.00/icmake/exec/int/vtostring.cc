//#define XERR
#include "int.ih"

string Int::vto_string() const
{
    return std::to_string(d_value);
}
