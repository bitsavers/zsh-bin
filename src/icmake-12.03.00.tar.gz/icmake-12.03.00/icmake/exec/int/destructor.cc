//#define XERR
#include "int.ih"

Int::~Int()
{}
