//#define XERR
#include "int.ih"

bool Int::vBool() const
{
    return d_value != 0;
}
