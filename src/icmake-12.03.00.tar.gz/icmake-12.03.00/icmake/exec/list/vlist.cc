//#define XERR
#include "list.ih"

vector<string> const &List::vList() const 
{
    return d_list;
}
