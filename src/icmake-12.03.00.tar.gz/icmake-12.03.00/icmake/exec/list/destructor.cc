//#define XERR
#include "list.ih"

List::~List()
{}
