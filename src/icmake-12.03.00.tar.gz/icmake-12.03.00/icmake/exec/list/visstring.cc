//#define XERR
#include "list.ih"

bool List::vIsString() const
{
    return false;
}
