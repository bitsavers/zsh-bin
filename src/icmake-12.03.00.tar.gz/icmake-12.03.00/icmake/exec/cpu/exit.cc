//#define XERR
#include "cpu.ih"

// d_reg's forced int-value is the return value

void CPU::exit() const
{}
