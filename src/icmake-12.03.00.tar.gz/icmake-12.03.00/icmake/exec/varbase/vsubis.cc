//#define XERR
#include "varbase.ih"

// virtual
VarBase &VarBase::vSubIs(VarBase const &rhs)
{
    xerr("");
    undefined();
}
