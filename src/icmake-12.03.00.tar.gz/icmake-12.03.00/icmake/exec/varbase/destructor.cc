//#define XERR
#include "varbase.ih"

VarBase::~VarBase()
{}
