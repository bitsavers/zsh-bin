//#define XERR
#include "varbase.ih"

// virtual
strong_ordering VarBase::vOrder(VarBase const &rhs) const
{
    xerr("");
    undefined();
}
