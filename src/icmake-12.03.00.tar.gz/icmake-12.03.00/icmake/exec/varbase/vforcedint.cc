//#define XERR
#include "varbase.ih"

int VarBase::vForcedInt() const
{
    xerr("");
    return 0;                   // String, List
}
