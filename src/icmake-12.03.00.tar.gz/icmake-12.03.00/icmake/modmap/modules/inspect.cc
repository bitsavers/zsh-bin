#define XERR
#include "modules.ih"

void Modules::inspect(Classes::Info const &info)
{
    pushDir(info.subdir);
//    cout << info.subdir << '\n';

    if (not exists("gcm.cache"))                    // to main's gcm.cache
        createSymlink("../gcm.cache", "gcm.cache");
//        createSymlink("/usr", "gcm.cache/usr");  // and to the system hdrs


    if (exists(d_interface_cc))
        scan(info, d_interface_cc);

    popDir();
}

