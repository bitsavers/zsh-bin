#define XERR
#include "modules.ih"

void Modules::fill()
{
    while (true)
    {
        Classes::Info info = d_classes.next();
        if (info.idx == 0)
            break;
        inspect(info);
    }

    for (string const &name: d_extern)      // add the external module names
        d_modules.push_back(Data{ -1, ""s, name });
}

//    for (Data const &entry: d_modules)
//    {
//        imsg << "Module " << entry.modName << ": nr " << entry.idx << 
//                " in subdir " << entry.subdir << '\n';
//        if (not entry.imports.empty())
//        {
//            for (string const &imported: entry.imports)
//                imsg << "   imports: " << imported << '\n';
//        }
//    }
