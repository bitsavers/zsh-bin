#define XERR
#include "modules.ih"

void Modules::addImports(Set &dest, Data const &data)
{
    for (string const &name: data.orgImports)   // visit all required modules
    {
        dest.insert(name);
                                                // add mods required by name
        addImports(dest, d_modules[d_modIdx[name]]);
    }
}
