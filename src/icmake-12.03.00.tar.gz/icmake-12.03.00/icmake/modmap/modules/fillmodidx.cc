#define XERR
#include "modules.ih"

void Modules::fillModIdx()
{
    for (size_t idx = 0, end = d_modules.size(); idx != end; ++idx)
        d_modIdx[d_modules[idx].modName] = idx;
}
