#define XERR
#include "modules.ih"

string Modules::s_compileCmd
    { " -c -fmodules-ts -Wall -o " };
