#define XERR
#include "modules.ih"

void Modules::removeModule(string const &modName, Vect::iterator next)
{
    for (; next != d_modules.end(); ++next)
        next->imports.erase(modName);
}
