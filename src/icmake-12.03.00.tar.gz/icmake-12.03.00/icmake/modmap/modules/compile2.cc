#define XERR
#include "modules.ih"

// cstdlib:
//     std::cout << getenv("ICMAKE_CXXFLAGS") << '\n';
// returns, e.g., --std=c++26

void Modules::compile(Process &proc, string const &objFile)
{
    string cmd = "/bin/g++ " + d_std + d_colors + s_compileCmd + 
                        objFile + ' ' + d_interface_cc;

    imsg << cmd << '\n';

    proc.setCommand(cmd);
    proc.start();

    if (proc.waitForChild() != 0)
    {
        emsg << cmd << "failed\n";
        throw 1;
    }
}
