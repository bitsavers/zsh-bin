#define XERR
#include "modules.ih"

// static
string Modules::col2hyphen(string const &name)
{
    string ret{ name };

    for (char &ch: ret)
    {
        if (ch == ':')
            ch = '-';
    }

    return ret;
}
