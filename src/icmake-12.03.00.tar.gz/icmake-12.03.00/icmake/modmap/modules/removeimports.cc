#define XERR
#include "modules.ih"

Modules::Vect::iterator Modules::removeImports(Vect::iterator from,
                                               Vect::iterator const &next)
{
    for (; from != next; ++from)
        removeModule(from->modName, next);

    return next;
}
