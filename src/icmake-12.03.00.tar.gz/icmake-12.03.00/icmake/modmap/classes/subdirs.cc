#define XERR
#include "classes.ih"

void Classes::subdirs(string const &list)
{
    vector<string> ignore;
    String::split(&ignore, list);

    for (char const *dirname: Glob{ Glob::DIRECTORY, "*", Glob::NOMATCH })
    {
        if (find(ignore.begin(), ignore.end(), dirname) != ignore.end())
            continue;
        d_classes.push_back(dirname);
    }
}
