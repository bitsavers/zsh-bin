#define XERR
#include "classes.ih"

void Classes::read()
{
                                        // open the CLASSES file
    ifstream classes{ Exception::factory<ifstream>("CLASSES") };

    string entry;                                       // get all 1st words
    while (classes >> entry and classes.ignore(1000, '\n'))   
    {
        if ("#/"s.find(entry[0]) != string::npos)       // skip comment lines
            continue;

//        imsg << entry << '\n';
        d_classes.push_back(move(entry));               // add the class name
    }
}
