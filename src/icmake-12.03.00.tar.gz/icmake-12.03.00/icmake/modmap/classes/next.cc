#define XERR
#include "classes.ih"

Classes::Info Classes::next()
{
    if (d_idx == 0)
        return Info{ 0, "" };

    --d_idx;
    return Info{ d_idx, d_classes[d_idx] };    
}
