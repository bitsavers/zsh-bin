#ifndef INCLUDED_CLASSES_
#define INCLUDED_CLASSES_

#include <vector>
#include <string>

class Classes
{
    using Vect = std::vector<std::string>;  

    Vect d_classes;         // the classes in CLASSES
    int d_idx;              // as 'int' is used by Modules::Data::idx

    public:
        struct Info
        {
            int idx;
            std::string const &subdir;
        };

        Classes();
        Info next();            // idx 0: all classes done

    private:
        void read();                            // read CLASSES
        void subdirs(std::string const &list);  // determine all subdirs
};
        
#endif
