#define XERR
#include "classes.ih"

Classes::Classes()
:
    d_classes(1)                    // initial 0: all classes done
{
    Arg const &arg = Arg::instance();

    string list;
    if (arg.option('n') or arg.option(&list, 'i'))
        subdirs(list);
    else
        read();

    d_idx = d_classes.size();       // return the last class first
}
