#define XERR
#include "support.ih"

    // no error checks: this function should work or throws an exception
void Support::popDir()
{
    if (not d_dirStack.empty())
        d_dirStack.pop();

    fs::current_path(d_dirStack.top());
}
