#define XERR
#include "support.ih"

bool Support::createDir(Path const &dir) const
{
    return 
        fs::create_directory(dir, s_errorCode) or s_errorCode.value() == 0;
}
