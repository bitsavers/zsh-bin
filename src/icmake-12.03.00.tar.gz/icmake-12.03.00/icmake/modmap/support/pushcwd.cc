#define XERR
#include "support.ih"

    // no error checks: this function should work or throws an exception

void Support::pushCwd()
{
    d_dirStack.push(fs::current_path());
}
