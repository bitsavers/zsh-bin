#define XERR
#include "support.ih"

    // no error checks: this function should work or throws an exception

void Support::pushDir(Path const &dir)
{
    fs::current_path(dir);
    d_dirStack.push(dir);
}
