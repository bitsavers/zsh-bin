#define XERR
#include "support.ih"

bool Support::younger(string const &srcFile, string const &objFile) const
{
    Stat obj{ objFile };

    return not obj?             // objFile doesn't exist
                true
            :
                Stat{ srcFile }.lastModification() >= obj.lastModification();
}
