#define XERR
#include "support.ih"

    // no error checks: this function should work or throws an exception

void Support::setCwd(string const &dir) const
{
    fs::current_path(dir);
}
