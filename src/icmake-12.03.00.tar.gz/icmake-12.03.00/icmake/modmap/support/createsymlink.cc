#define XERR
#include "support.ih"

void Support::createSymlink(Path const &dest, Path const &link) const
{
    fs::create_symlink(dest, link, s_errorCode);
}
