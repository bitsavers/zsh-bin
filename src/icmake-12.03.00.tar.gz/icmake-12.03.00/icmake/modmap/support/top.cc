#define XERR
#include "support.ih"

Support::Path const &Support::top() const
{
    return d_dirStack.top();
}
