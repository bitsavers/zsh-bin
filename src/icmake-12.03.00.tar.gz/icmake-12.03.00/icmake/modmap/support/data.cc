#include "support.h"

std::error_code Support::s_errorCode;

