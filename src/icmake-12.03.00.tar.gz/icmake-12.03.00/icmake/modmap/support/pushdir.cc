#define XERR
#include "support.ih"

    // no error checks: this function should work or throws an exception

void Support::pushDir(DirEntry const &dir)
{
    pushDir(dir.path());
}
