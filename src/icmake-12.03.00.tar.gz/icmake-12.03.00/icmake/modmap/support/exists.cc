#define XERR
#include "support.ih"

bool Support::exists(string const &fname) const
{
    return fs::exists(fname, s_errorCode);
}
