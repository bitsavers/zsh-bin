#define XERR
#include "support.ih"

bool Support::createDirs(Path const &dir) const
{
    return 
        fs::create_directories(dir, s_errorCode) or s_errorCode.value() == 0;
}
