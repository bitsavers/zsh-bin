#include "chartab.ih"

int chartab_data = 0;   /* to ensure linkage via chartabconstruct.c     */
Chartab chartab;        /* Initialized to 0 by the compiler             */
