#include "process.ih"

Process::Process(Line &line)
:
    d_line(line)
{}
