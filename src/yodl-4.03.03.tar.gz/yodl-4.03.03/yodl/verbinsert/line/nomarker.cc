#include "line.ih"

bool Line::noMarker()
{
    return false;
}
