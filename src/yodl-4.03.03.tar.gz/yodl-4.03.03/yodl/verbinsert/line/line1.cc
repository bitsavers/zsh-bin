#include "line.ih"

Line::Line()
:
    d_input(&cin)
{}
