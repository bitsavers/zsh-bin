
#include "yodl.h"

void gram_IFZERO()
{
    parser_if_cond(&parser, parser_if_zero, "IFZERO", 3);
}
