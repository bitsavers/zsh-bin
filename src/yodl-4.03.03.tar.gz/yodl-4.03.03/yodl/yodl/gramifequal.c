
#include "yodl.h"

void gram_IFEQUAL()
{
    parser_if_cond(&parser, parser_if_equal, "IFEQUAL", 4);
}
