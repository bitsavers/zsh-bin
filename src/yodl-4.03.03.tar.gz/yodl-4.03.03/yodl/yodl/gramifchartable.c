#include "yodl.h"

void gram_IFCHARTABLE()
{
    parser_if(&parser, CHARTABLE, "IFCHARTABLE");
}
