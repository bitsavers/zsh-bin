
#include "yodl.h"

void gram_IFSTREQUAL()
{
    parser_if_cond(&parser, parser_if_strequal, "IFSTREQUAL", 4);
}
