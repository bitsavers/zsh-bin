#include "yodl.h"

void gram_IFMACRO()
{
    parser_if(&parser, MACRO, "IFMACRO");
}
