#include "yodl.h"

void gram_IFCOUNTER()
{
    parser_if(&parser, COUNTER, "IFCOUNTER");
}
