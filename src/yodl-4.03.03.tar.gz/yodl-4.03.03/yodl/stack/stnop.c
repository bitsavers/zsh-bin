#include "stack.ih"

void st_nop(register void *nop)
{}
