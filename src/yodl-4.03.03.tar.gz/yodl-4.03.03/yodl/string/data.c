#include "string.ih"

char const s_stringEmpty[] = "";
