#include "parser.ih"

bool p_handle_ignore(register Parser *pp)
{
    return true;
}
