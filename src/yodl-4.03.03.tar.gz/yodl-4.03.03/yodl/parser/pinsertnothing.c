#include "parser.ih"

void p_insert_nothing(register Parser *pp, char const *txt)
{}
