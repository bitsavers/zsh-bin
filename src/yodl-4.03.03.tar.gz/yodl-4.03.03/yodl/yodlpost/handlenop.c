#include "yodlpost.h"

void handle_nop(long offset, HashItem *item)
{}
