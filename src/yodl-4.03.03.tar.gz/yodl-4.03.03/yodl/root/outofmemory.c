#include "root.ih"

void out_of_memory()
{
    fprintf(stderr, "Out of memory\n");
    exit(1);
}
