#include "args.ih"

int args_data = 0;      /* to ensure linkage via argsconstruct.c    */

Args args;              /* initialized to 0 by the compiler */

